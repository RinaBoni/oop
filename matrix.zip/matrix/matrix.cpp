﻿// matrix.cpp : Этот файл содержит функцию "main". Здесь начинается и заканчивается выполнение программы.
//

#include <iostream>
#include <vector>
#include <time.h>
using namespace std;

void filling_vec(vector <vector <int>>& vec);
void print_vec(vector <vector <int>>& vec);

int main()
{
    vector <vector <int>> vec;
    int col, row;
    cout << "enter col: ";
    cin >> col;
    cout << "enter row: ";
    cin >> row;
    vec.resize(row);
    for (int i = 0; i < row; i++)
    {
        vec[i].resize(col);
    }
    filling_vec(vec);
    print_vec(vec);
}

void filling_vec(vector <vector <int>>& vec)
{
    srand(time(NULL));
    for (int i = 0; i < vec.size(); i++)
    {
        for (int j = 0; j < vec[i].size(); j++)
        {
            vec[i][j] = rand() % 10 - 1;
        }
    }
}

void print_vec(vector <vector <int>>& vec)
{
    cout << "matrix:\n";
    for (int i = 0; i < vec.size(); i++)
    {
        for (int j = 0; j < vec[i].size(); j++)
        {
            cout << vec[i][j] << "\t";
        }
        cout << "\n";
    }
}