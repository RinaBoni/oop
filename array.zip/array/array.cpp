﻿// заполнение и вывод массива
//

#include <iostream>
#include <time.h>
#include "Header.h"

using namespace array_ns;

int main()
{
    int n;                                  //n - размер массива
    std::cout << "enter n: ";
    std::cin >> n;
    int* array = new int[n];                //выделение память под массивв
    filling_array(array, n);                //заполнение массива
    print_array(array, n);                  //вывод массива
}